<?php  
class data_model extends CI_Model {  
function __construct()  
{  
    parent::__construct();  
    $this->load->database();  
}  
  

    public function login($data){
    	$query=$this->db->get_where('tbl_admin',array('email'=>$data['user'],'password'=>$data['password']));  
    return $query->num_rows();
    }

    public function sdetail(){
    	$query=$this->db->query(" select * from tbl_student");
    	return $query->result();
    }

    public function tutordetail(){
        $query=$this->db->query(" select * from tbl_tutor");
        return $query->result();
    }

    public function subject_detail(){
        $query=$this->db->query(" select * from course");
        return $query->result();
    }

     public function countstud(){
        $sql="select count(id) as id from tbl_student";
        $query=$this->db->query($sql);
        return $query->row()->id;
    }   

     public function counttutor(){
        $sql="select count(id) as id from tbl_tutor";
        $query=$this->db->query($sql);
        return $query->row()->id;
    }   

    public function edit_tutor($id){
        // $this->db->where('id',$id);
        $sql="select * from tbl_tutor where id='$id'";
        $query=$this->db->query($sql);
        return $query->result();
    }

    public function update($name,$email,$add,$contact,$id){
        // echo $name, $email, $password, $add, $contact, $id;

        $sql="update tbl_tutor set name='$name', email='$email',address='$add',contact='$contact' where id='$id'";
        $this->db->query($sql);
        return true;
    }

     public function delete($id){
        // $this->db->where('id',$id);
        $sql="delete from tbl_tutor where id='$id'";
        $query=$this->db->query($sql);
        return $query;
    }

    public function delete_stud($id){
        // $this->db->where('id',$id);
        $sql="delete from tbl_student where id='$id'";
        $query=$this->db->query($sql);
        return $query;
    }

     public function edit_student($id){
        // $this->db->where('id',$id);
        $sql="select * from tbl_student where id='$id'";
        $query=$this->db->query($sql);
        return $query->result();
    }

    public function update_stud($name,$email,$add,$contact,$id){
        // echo $name, $email, $password, $add, $contact, $id;

        $sql="update tbl_student set name='$name', email='$email',address='$add',contact='$contact' where id='$id'";
        $this->db->query($sql);
        return true;
    }

}