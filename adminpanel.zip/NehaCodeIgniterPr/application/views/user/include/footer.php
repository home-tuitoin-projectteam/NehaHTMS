<script src="<?php echo base_url();?>assetes_user/vendor/common/common.min.js"></script>
    <script src="<?php echo base_url();?>assetes_user/js/custom.min.js"></script>
    <script src="<?php echo base_url();?>assetes_user/js/settings.js"></script>
    <script src="<?php echo base_url();?>assetes_user/js/quixnav.js"></script>
    <script src="<?php echo base_url();?>assetes_user/js/styleSwitcher.js"></script>
    
    
    <!-- ChartJS -->
    <script src="<?php echo base_url();?>assetes_user/vendor/chart.js/Chart.bundle.min.js"></script>
    <!-- Ticker -->
    <script src="<?php echo base_url();?>assetes_user/vendor/webticker/jquery.webticker.min.js"></script>

    <!--  flot-chart js -->
    <script src="<?php echo base_url();?>assetes_user/vendor/flot/jquery.flot.js"></script>
    <script src="<?php echo base_url();?>assetes_user/vendor/flot/jquery.flot.resize.js"></script>

    <!-- Counter Up -->
    <script src="<?php echo base_url();?>assetes_user/vendor/waypoints/jquery.waypoints.min.js"></script>
    <script src="<?php echo base_url();?>assetes_user/vendor/jquery.counterup/jquery.counterup.min.js"></script>



    <script src="<?php echo base_url();?>assetes_user/js/dashboard/dashboard-1.js"></script>

</body>
</html>