<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Arvid - Bootstrap Cryptocurrency Admin Dashboard HTML Template</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url();?>assetes_user/images/favicon.png">
    <!-- Custom Stylesheet -->
    <link rel="stylesheet" href="<?php echo base_url();?>assetes_user/vendor/owl.carousel/dist/css/owl.carousel.min.css">
    <link href="<?php echo base_url();?>assetes_user/vendor/fullcalendar/css/fullcalendar.min.css" rel="stylesheet">
    <!-- Chartist -->
    <link rel="stylesheet" href="<?php echo base_url();?>assetes_user/vendor/chartist/css/chartist.min.css">
    <link href="<?php echo base_url();?>assetes_user/css/style.css" rel="stylesheet">

</head>

<body>