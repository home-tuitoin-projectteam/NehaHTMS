<!DOCTYPE html>
<html>
	<head>
		<title>Student Details</title>
	</head>
	<body>
		<div class="page-wrapper">
		
			<div class="container-fluid">	
				<div class="row page-titles">
		<table class="table table-striped">
			<thead class="thead-dark">
			<tr>
				<th scope="col">S. No.</th>
				<th scope="col">Name</th>
				<th scope="col">Email</th>
				<th scope="col">Contact</th>
				<th scope="col">Address</th>
				<th scope="col">Registration Time</th>
				<th colspan="2">Action</th>
			</tr>
			</thead>
			<tbody>
			
			<?php 
			$s=1;
			foreach ($data as $row)
			{?>
				<tr>
				<td><?php echo $s;?></td>
				<td scope='row'><?php echo $row->name ;?></td>
				<td scope='row'><?php echo $row->email ;?></td>
				<td scope='row'><?php echo $row->contact ;?></td>
				<td scope='row'><?php echo $row->address ;?></td>
				<td scope='row'><?php echo $row->registered_time ;?></td>
				<td scope='row'><a href="edit/?id=<?php echo $row->id; ?>"><button class=" btn btn-primary ">Edit</button></a></td>
				<td scope='row'><a href="delete/?id=<?php echo $row->id; ?>"><i class="fa fa-trash fa-2x" style="color:red;"></i></a></td>
				</tr>
				
			<?php $s++; }?>
			</tbody>
		</table>
		</div></div></div>
	</body>
</html>