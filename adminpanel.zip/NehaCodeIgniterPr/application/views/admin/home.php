<!DOCTYPE html>
<html lang="en">
<head>
	<title>Admin Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="<?= base_url().'assets/' ?>admin/css/util.css">
<link rel="stylesheet" type="text/css" href="<?= base_url().'assets/' ?>admin/css/main.css">
	
	<link rel="icon" type="image/png" href="<?= base_url().'assets/' ?>admin/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?= base_url().'assets/' ?>admin/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?= base_url().'assets/' ?>admin/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?= base_url().'assets/' ?>admin/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?= base_url().'assets/' ?>admin/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="<?= base_url().'assets/' ?>admin/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?= base_url().'assets/' ?>admin/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?= base_url().'assets/' ?>admin/vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="<?= base_url().'assets/' ?>admin/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-t-50 p-b-90">
				<?php echo form_open('Admin/check_login')?>

				<form id="sign_in" method="POST" action="">
					<span class="login100-form-title p-b-51">
						Login
					</span>
					<div class="wrap-input100 validate-input m-b-16" data-validate = "Username is required">
						<input class="input100" type="text" name="username" id="username" placeholder="Username" autocomplete="off">
					</div>	
					<div class="wrap-input100 validate-input m-b-16" data-validate = "Password is required">
						<input class="input100" type="password" name="pass" id="password" placeholder="Password">
						
					</div>
					
					<div class="flex-sb-m w-full p-t-3 p-b-24">
						<div class="contact100-form-checkbox">
							
						</div>
						

						<div>
							<a href="<?= base_url().'forget_password'?>" class="txt1">
								Forgot?
							</a>
						</div>
					</div>

					<div class="container-login100-form-btn m-t-17">
						<input type="submit" name="sub" class="login100-form-btn" id="login" value="Login">
						<!-- <button class="btn btn-block waves-effect" type="submit" id="submit"> -->
                            
                           <!--  login
                            </button>	 -->
					</div>

				</form>
				
			</div>
		</div>
	</div>

	<div id="dropDownSelect1"></div>
	
	
<!--===============================================================================================-->
	<script src="<?= base_url().'assets/' ?>admin/vendor/jquery/jquery-3.2.1.min.js"></script>
	
	<script src="<?= base_url().'assets/admin/login.js' ?>"></script>
<!--===============================================================================================-->
	<script src="<?= base_url().'assets/' ?>admin/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="<?= base_url().'assets/' ?>admin/vendor/bootstrap/js/popper.js"></script>
	<script src="<?= base_url().'assets/' ?>admin/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="<?= base_url().'assets/' ?>admin/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="<?= base_url().'assets/' ?>admin/vendor/daterangepicker/moment.min.js"></script>
	<script src="<?= base_url().'assets/' ?>admin/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="<?= base_url().'assets/' ?>admin/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="<?= base_url().'assets/' ?>admin/js/main.js"></script>

</body>
</html>