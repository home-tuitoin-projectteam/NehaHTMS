<!DOCTYPE html>
<html>
<head>
	<title>Update Student Detail</title>

</head>
<body>
	 <div class="page-wrapper"> 
	 	<div class="row page-titles">
	 	</div>
	<div class="container-fluid">
		<div class="container">

			<?php echo form_open('Admin/check_update')?>
		<form>
			 <input type="hidden" class="form-control" name="id" value="<?php echo $t[0]->id;?>">
  			<div class="form-group row">
   				<label class="col-sm-2 col-form-label">Name</label>
    				<div class="col-sm-10">
     					 <input type="text" class="form-control" name="name" value="<?php echo $t[0]->name;?>">
    				</div>
  			</div>
  			<div class="form-group row">
   				<label class="col-sm-2 col-form-label">Email</label>
    				<div class="col-sm-10">
     					 <input type="text" class="form-control" name="email" value="<?php echo $t[0]->email;?>">
    				</div>
  			</div>
  			<!-- <div class="form-group row">
   				 <label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
    				<div class="col-sm-10">
      					<input type="text" class="form-control" name="pass" value="<?php echo $t[0]->password;?>">
    				</div>
  			</div> -->
  			<div class="form-group row">
   				<label class="col-sm-2 col-form-label">Address</label>
    				<div class="col-sm-10">
     					 <input type="text" class="form-control" name="add" value="<?php echo $t[0]->address;?>">
    				</div>
  			</div>
  			<div class="form-group row">
   				<label class="col-sm-2 col-form-label">Contact</label>
    				<div class="col-sm-10">
     					 <input type="text" class="form-control" name="contact" value="<?php echo $t[0]->contact;?>">
    				</div>
  			</div>
  			<input type="submit" value="submit" name="submit" class="btn btn-success">
		</form>
	</div>
	</div>
</div>
</body>
</html>