<!DOCTYPE html>
<html>
	<head>
		<title>Student Details</title>
	</head>
	<body>
		<div class="page-wrapper">
		
			<div class="container-fluid">	
				<div class="row page-titles">
		<table class="table table-striped">
			<thead class="thead-dark">
			<tr>
				<th scope="col">S. No.</th>
				<th scope="col">Course Name</th>
				<th scope="col">Fees</th>
				<th scope="col">Time</th>
				
			</tr>
			</thead>
			<tbody>
			
			<?php 
			$s=1;
			foreach ($data as $row)
			{
				echo"<tr>";
				echo"<td>".$s."</td>";
				echo"<td scope='row'>".$row->course_name."</td>";
				echo"<td scope='row'>".$row->fees."</td>";
				echo"<td scope='row'>".$row->time."</td>";
				echo"</tr>";
				$s++;
			 }?>
			</tbody>
		</table>
		</div></div></div>
	</body>
</html>