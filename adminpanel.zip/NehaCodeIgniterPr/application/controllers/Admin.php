<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct()
	{
	parent::__construct();
	$this->load->helper('form');
	$this->load->model('Data_model');
	$this->load->library('session');

	}

	function header(){
		$this->load->view('admin/include/header');

			
	}

	function sidebar(){
		$this->load->view('include/nav_menu');
	}

	function footer(){
		$this->load->view('admin/include/footer');
	}
	
	public function index()
	{
	
		$this->load->view('admin/home');
		
	}

	public function check_login(){
			   
	$data['user']=htmlspecialchars($_POST['username']);  
    $data['password']=htmlspecialchars($_POST['pass']); 

   
    $res=$this->Data_model->login($data);  
    if($res){     
        $this->session->set_userdata('id',$data['user']);   
      	  
        redirect(base_url().'dashboard1');
    }  
    else{ 
     echo'username or password wrong ?' ;
        
    }
	} 

	public function dashboard(){
		
		$this->header();
		$result['data']=$this->Data_model->countstud();
		$result['t']=$this->Data_model->counttutor();
		 $this->load->view('admin/dashboard1',$result);
	} 			
	public function email(){
		$this->load->view('admin/app-email');
		
	}
	public function maildetail(){
		$this->load->view('admin/app-email-detail');
		 
	}
	public function compose(){
		$this->load->view('admin/app-compose');
	}

	public function subdetail(){
		$this->header();
		$result['data']=$this->Data_model->subject_detail();
		$this->load->view('admin/subject',$result);
	}

	public function studetail(){
		$this->header();
		$result['data']=$this->Data_model->sdetail();
		$this->load->view('admin/student',$result);
	}

	public function tutordetail(){
		$this->header();
		$result['data']=$this->Data_model->tutordetail();
		$this->load->view('admin/tutor',$result);
		 //$this->footer();
	}

	public function class(){
		$this->load->view('admin/assign_class');
		 //$this->footer();
	}

	public function assign_tutor(){
		$this->load->view('admin/assign_tutor');
		 //$this->footer();
	}

	public function assign_student(){
		$this->load->view('admin/assign_stud');
		 //$this->footer();
	}

	public function profile(){
		$this->load->view('admin/page-profile');
		 //$this->footer();
	}

	public function edit(){
		$this->header();
		$id=$this->input->get('id');
		$data['t']=$this->Data_model->edit_tutor($id);
		$this->load->view('admin/edit_tutor',$data);
	}

	public function check_update(){
		if($this->input->post('submit'))
		{
			$a=$this->input->post('name');
			$b=$this->input->post('email');
			$c=$this->input->post('pass');
			$d=$this->input->post('add');
			$e=$this->input->post('contact');
			$f=$this->input->post('id');
			// echo $a, $b, $c, $d, $e, $f;
		$res=$this->Data_model->update($a,$b,$c,$d,$e,$f);
		if($res){
			redirect(base_url().'tutor_detail');
		}
	
	}
}

	public function delete(){
		$id=$this->input->get('id');
		$data=$this->Data_model->delete($id);
		// $this->load->view('admin/edit_tutor',$data);
		if($data){
		redirect(base_url().'tutor_detail');
	}
	}

	public function delete_stud(){
		$id=$this->input->get('id');
		$data=$this->Data_model->delete_stud($id);
		// $this->load->view('admin/edit_tutor',$data);
		if($data){
		redirect(base_url().'student_detail');
	}
	}

	public function edit_stud(){
		$this->header();
		$id=$this->input->get('id');
		$data['s']=$this->Data_model->edit_student($id);
		$this->load->view('admin/edit_student',$data);
	}

	public function check_update_stud(){
		if($this->input->post('submit'))
		{
			$a=$this->input->post('name');
			$b=$this->input->post('email');
			
			$d=$this->input->post('add');
			$e=$this->input->post('contact_no');
			$f=$this->input->post('id');
			 echo $a, $b, $d, $e, $f;
		// $res=$this->Data_model->update_stud($a,$b,$c,$d,$e,$f);
		// if($res){
		// 	redirect(base_url().'tutor_student');
		// }
	
	}
}
}

