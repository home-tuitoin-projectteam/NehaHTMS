<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Enduser';
$route['404_override'] = 'error';
$route['translate_uri_dashes'] = FALSE;


/* My New Routes for EndUsers */
/* Start */

$route['about']='Enduser/about';
$route['subject']='Enduser/subject';
$route['counselling']='Enduser/fccon';
$route['register']='Enduser/register';
$route['contact']='Enduser/contact';
$route['dashboard']='Enduser/user_dashboard';

/*admin controller start*/

$route['admin']='Admin'; 
$route['dashboard1']='Admin/dashboard';
$route['check_login']='Admin/check_login';
$route['email']='Admin/email';
$route['maildetail']='Admin/detail';
$route['compose_mail']='Admin/compose';
$route['subdetail']='Admin/subdetail';
$route['student_detail']='Admin/studetail';
$route['tutor_detail']='Admin/tutordetail';
$route['assign_class']='Admin/class';
$route['assign_student']='Admin/assign_student';
$route['assign_tutor']='Admin/assign_tutor';
$route['profile']='Admin/profile';
$route['edit']='Admin/edit';
$route['delete']='Admin/delete';
$route['edit_student']='Admin/edit_stud';
$route['delete']='Admin/delete_student';




/* End */
/* My New Routes for EndUsers */