    $('#sign_in').submit(function(event)
{
    event.preventDefault();
   
    var formset=$(this).serialize();
  // alert(formset);

            $.ajax(
    {
        type: 'POST',
        data: formset,
        url:<?= base_url().'check_login'>, 
        success: function(data)
    {
      if(data !== '0')
            {
                alert('success');
            }
            else
            {
              alert('failed');
            }
        }
    });

    
});


